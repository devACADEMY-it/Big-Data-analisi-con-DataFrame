from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder \
        .master('local') \
        .appName('EsempioSpark') \
        .getOrCreate()

df = spark.read.csv('dati_sett_2015.csv', inferSchema=True, header=True)
df.registerTempTable('indice')

spark.sql("SELECT 'Pos', count(*) as quanti FROM indice WHERE Close>Open UNION SELECT 'Non Pos', count(*) as quanti FROM indice WHERE Close<=Open").show()

spark.sql("SELECT month(Date) as Month, max(Close) as maxi, min(Close) as mini, max(Close)-min(Close) as diff FROM indice GROUP BY month(Date) ORDER BY diff").show()

spark.stop()
