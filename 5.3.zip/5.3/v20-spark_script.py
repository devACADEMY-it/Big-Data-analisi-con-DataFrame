from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder \
        .master('local') \
        .appName('EsempioSpark') \
        .getOrCreate()

df=spark.read.csv('dati_sett_2015.csv', inferSchema=True, header=True)
df=df.withColumn('Month', F.month(df.Date))

df.groupBy(df.Month).agg(F.max(df.Close).alias('max'), F.min(df.Close).alias('min'), (F.max(df.Close)-F.min(df.Close)).alias('diff') ).orderBy('diff').show()

spark.stop()
