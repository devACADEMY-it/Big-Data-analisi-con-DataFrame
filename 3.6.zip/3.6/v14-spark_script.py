from pyspark.sql import SparkSession

spark = SparkSession.builder \
        .master('local') \
        .appName('EsempioSpark') \
        .getOrCreate()

df = spark.read.csv('dati_sett_2015.csv', inferSchema=True, header=True)
prima=df.orderBy(df.Date).first().Close
ultima=df.orderBy(df.Date, ascending=False).first().Close
diff=ultima-prima
diffPerc=diff/prima*100

print(f'Differenza  :  {diff}')
print(f'Differenza %:  {diffPerc}%')

spark.stop()
