from pyspark.sql import SparkSession

spark = SparkSession.builder \
        .master('local') \
        .appName('EsempioSpark') \
        .getOrCreate()

df=spark.read.json('segnalazioni')
finale=df.filter((df.infortuni==0) & (df.ammonizioni>=0) & (df.goal>=10))
finale.select(finale.cognome, finale.nome).write.csv('selezionati', header=True)

spark.stop()
