from pyspark.sql import SparkSession

spark = SparkSession.builder \
        .master('local') \
        .appName('EsempioSpark') \
        .getOrCreate()

# codice da attivare
print('Hello Spark!')

spark.stop()
