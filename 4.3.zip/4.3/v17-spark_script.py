from pyspark.sql import SparkSession
from pyspark.sql import functions as F

spark = SparkSession.builder \
        .master('local') \
        .appName('EsempioSpark') \
        .getOrCreate()

df=spark.read.csv('dati_sett_2015.csv', inferSchema=True, header=True)
df=df.withColumn('DiffCloseOpen', df.Close-df.Open).withColumn('Month', F.month(df.Date))
settimanePos=df.filter((df.Month.between(6,8)) & (df.DiffCloseOpen>0)).count()
settimaneNonPos=df.filter((df.Month.between(6,8)) & (df.DiffCloseOpen<=0)).count()

print(f'Positive: {settimanePos}')
print(f'Non positive: {settimaneNonPos}')
spark.stop()
